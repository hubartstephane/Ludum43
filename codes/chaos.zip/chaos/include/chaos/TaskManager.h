#pragma once

#include <chaos/StandardHeaders.h>
#include <chaos/ReferencedObject.h>

namespace chaos
{
	class TaskManager : public ReferencedObject
	{

	};

}; // namespace chaos
