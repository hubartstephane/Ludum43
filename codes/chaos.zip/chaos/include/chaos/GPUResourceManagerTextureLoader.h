#pragma once

#include <chaos/StandardHeaders.h>
#include <chaos/GPUResourceManagerLoader.h>
#include <chaos/GPUResourceManager.h>
#include <chaos/GPUTexture.h>
#include <chaos/GPUTextureLoader.h>
#include <chaos/JSONTools.h>
#include <chaos/FilePath.h>

namespace chaos
{

	class GPUResourceManagerTextureLoader : public GPUResourceManagerLoader<GPUTextureLoader, GPUResourceManager>
	{
	public:

		/** constructor */
		GPUResourceManagerTextureLoader(GPUResourceManager * in_resource_manager) :
			GPUResourceManagerLoader<GPUTextureLoader, GPUResourceManager>(in_resource_manager)
		{

		}

		/** texture loading from JSON */
		virtual GPUTexture * GenTextureObject(nlohmann::json const & json, boost::filesystem::path const & config_path, GenTextureParameters const & parameters) const override;
		/** texture loading from path */
		virtual GPUTexture * GenTextureObject(FilePathParam const & path, GenTextureParameters const & parameters = GenTextureParameters()) const override;

	protected:

		/** search whether the path is already in used in the manager */
		virtual bool IsPathAlreadyUsedInManager(FilePathParam const & path) const override;
		/** search whether the name is already in used in the manager */
		virtual bool IsNameAlreadyUsedInManager(std::string const & in_name) const override;
	};

}; // namespace chaos
