﻿#include <chaos/GPUVertexBuffer.h>

namespace chaos
{
	GPUVertexBuffer::GPUVertexBuffer(GLuint in_id) : GPUBuffer(in_id)
	{

	}

}; // namespace chaos
