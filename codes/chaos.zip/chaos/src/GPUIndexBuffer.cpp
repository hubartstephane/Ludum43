﻿#include <chaos/GPUIndexBuffer.h>

namespace chaos
{
	GPUIndexBuffer::GPUIndexBuffer(GLuint in_id) : GPUBuffer(in_id)
	{

	}

}; // namespace chaos
