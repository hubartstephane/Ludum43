#include <chaos/SkinnedMesh.h>

namespace chaos
{
}; // namespace chaos
