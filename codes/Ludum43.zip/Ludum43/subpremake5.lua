-- =============================================================================
-- ROOT_PATH/executables/LUDUM/Ludum43
-- =============================================================================

  WindowedApp()
  DependOnLib("CHAOS")
  DependOnLib("DEATH")
  DeclareResource("resources")    
