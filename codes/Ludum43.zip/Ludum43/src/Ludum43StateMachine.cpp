#include "Ludum43StateMachine.h"
#include "Ludum43Game.h"

LudumStateMachine::LudumStateMachine(class LudumGame * in_game) : 
	death::GameStateMachine(in_game)
{
}