#pragma once


#include "Ludum43Particles.h"
#include "Ludum43Game.h"

#include <chaos/CollisionFramework.h>
#include <chaos/ClassTools.h>


// ===========================================================================
// Utility functions
// ===========================================================================

template<typename T>
static bool ApplyAffectorToParticles(float delta_time, T * particle, ParticleAffector const & affector, bool & in_inner_radius, float inner_radius_factor)
{
	glm::vec2 & particle_position = particle->bounding_box.position;
	glm::vec2 & particle_velocity = particle->velocity;

	glm::vec2 const & affector_position = affector.bounding_box.position;

	glm::vec2 delta_pos = (affector_position - particle_position);

	float l2 = glm::length2(delta_pos);

	float attraction_maxradius = particle->particle_radius_factor * affector.attraction_maxradius;
	float attraction_minradius = particle->particle_radius_factor * affector.attraction_minradius;

	// particle in range
	if (l2 < attraction_maxradius * attraction_maxradius)
	{
		float l  = 0.0f;
		// particle never goes below lin radius
		if (l2 < attraction_minradius * attraction_minradius)
		{		
			l  = attraction_minradius;
			particle_position = affector_position - glm::normalize(delta_pos) * l;
		}
		else		
		{
			l = chaos::MathTools::Sqrt(l2);
		}

		// whether the particle is inside the inner radius
		float inner_radius = attraction_minradius + inner_radius_factor * (attraction_maxradius - attraction_minradius);
		if (l <= inner_radius)
			in_inner_radius = true;

		float distance_ratio = 1.0f;
		distance_ratio = chaos::MathTools::Clamp(1.0f - (l - attraction_minradius) / (attraction_maxradius - attraction_minradius));

		// create a tangent force
		if (glm::length2(particle_velocity) > 0.0f)
		{
			glm::vec3 a = glm::normalize(glm::vec3(delta_pos.x, delta_pos.y, 0.0f));
			glm::vec3 b = glm::vec3(0.0f, 0.0f, 1.0f);
			glm::vec3 tangent = glm::cross(a, b);

			particle_velocity = particle_velocity + distance_ratio * affector.tangent_force * glm::vec2(tangent.x, tangent.y);
		}

		particle_velocity = particle_velocity + distance_ratio *  affector.attraction_force * delta_pos; 

		return true;
	}
	return false;
}


template<typename T>
bool UpdateParticleLifeAndColor(T * particle, bool in_inner_radius, float delta_time, float lifetime)
{
	if (in_inner_radius)
	{
		particle->life = chaos::MathTools::Clamp(particle->life - delta_time, 0.0f, lifetime);	
		if (particle->life <= 0.0f)
			return true; // destroy the particle
	}
	else
	{
		particle->life = chaos::MathTools::Clamp(particle->life + delta_time, 0.0f, lifetime);	
	}

	particle->color.a = particle->life / lifetime;
	return false;
}

// ===========================================================================
// ParticlePlayerTrait
// ===========================================================================

size_t ParticlePlayerTrait::ParticleToVertices(ParticlePlayer const * p, VertexBase * vertices, size_t vertices_per_particle, chaos::ParticleAllocation * allocation) const
{
	return chaos::ParticleDefault::ParticleTrait::ParticleToVertices(p, vertices, vertices_per_particle, allocation);
}

ParticlePlayerTrait::UpdatePlayerData ParticlePlayerTrait::BeginUpdateParticles(float delta_time, ParticlePlayer * particles, size_t count, chaos::ParticleAllocation * allocation) const
{
	ParticlePlayerTrait::UpdatePlayerData result;

	//game->RegisterEnemiesInRange(result.player_particle.bounding_box.position, result.world_clamp_radius, result.enemy_particles);
	

	return result;
}


bool ParticlePlayerTrait::UpdateParticle(float delta_time, ParticlePlayer * particle, chaos::ParticleAllocation * allocation, UpdatePlayerData const & update_data) const
{
	// search all nearby enemies
	std::vector<ParticleEnemy> enemy_particles;
	game->RegisterEnemiesInRange(particle->bounding_box.position, game->world_clamp_radius, enemy_particles);

	// position of the particle
	glm::vec2 & particle_position = particle->bounding_box.position;
	glm::vec2 & particle_velocity = particle->velocity;

	// apply all effectors
	bool affected = false;

	bool in_danger_zone = false;

	size_t enemy_count = enemy_particles.size();
	for (size_t i = 0 ; i < enemy_count ; ++i)
		affected |= ApplyAffectorToParticles(delta_time, particle, enemy_particles[i], in_danger_zone, DANGER_RADIUS_RATIO);

	// update life and color
	if (UpdateParticleLifeAndColor(particle, in_danger_zone, delta_time, PLAYER_LIFETIME))
		return true;

#if 0

	// final computation
	float particle_max_velocity = update_data.particle_max_velocity;

	

	// particle slowing down
	if (!affected)
		particle->velocity *= powf(update_data.particle_slowing_factor, delta_time);	

	// update particle velocity
	float velocity_length2 = glm::length2(particle_velocity);
	if (velocity_length2 > particle_max_velocity * particle_max_velocity)
		particle_velocity = glm::normalize(particle_velocity) * particle_max_velocity;				
	// update particle position
	particle_position += particle->velocity * (float)delta_time;



#endif

	return false;
}
















// ===========================================================================
// ParticleEnemyTrait
// ===========================================================================

size_t ParticleEnemyTrait::ParticleToVertices(ParticleEnemy const * p, VertexBase * vertices, size_t vertices_per_particle, chaos::ParticleAllocation * allocation) const
{
	return chaos::ParticleDefault::ParticleTrait::ParticleToVertices(p, vertices, vertices_per_particle, allocation);
}

ParticleEnemyTrait::UpdateEnemyData ParticleEnemyTrait::BeginUpdateParticles(float delta_time, ParticleEnemy * particles, size_t count, chaos::ParticleAllocation * allocation) const
{
	ParticleEnemyTrait::UpdateEnemyData result;
	

	return result;
}

bool ParticleEnemyTrait::UpdateParticle(float delta_time, ParticleEnemy * particle, chaos::ParticleAllocation * allocation, ParticleEnemyTrait::UpdateEnemyData const & update_data) const
{
	




	return false;
}


// ===========================================================================
// ParticleAtomTrait
// ===========================================================================

size_t ParticleAtomTrait::ParticleToVertices(ParticleAtom const * p, VertexBase * vertices, size_t vertices_per_particle, chaos::ParticleAllocation * allocation) const
{
	return chaos::ParticleDefault::ParticleTrait::ParticleToVertices(p, vertices, vertices_per_particle, allocation);
}











bool ParticleAtomTrait::UpdateParticle(float delta_time, ParticleAtom * particle, chaos::ParticleAllocation * allocation, ParticleAtomTrait::UpdateAtomData const & update_data) const
{
	glm::vec2 const & player_position   = update_data.player_particle.bounding_box.position;
	glm::vec2 & particle_position = particle->bounding_box.position;

	glm::vec2 delta_pos = (player_position - particle_position);

	float l2 = glm::length2(delta_pos);
	float l  = 0.0f;

	// particle too far ?
	if (l2 > update_data.world_clamp_radius * update_data.world_clamp_radius)
		return false;

	// apply all effectors

	bool in_waken_up_zone = false;

	bool affected = false;
	affected |= ApplyAffectorToParticles(delta_time, particle, update_data.player_particle, in_waken_up_zone, WAKEN_RADIUS_RATIO);
	
	if (in_waken_up_zone && !particle->waken_up)
	{
		game->NotifyAtomCountChange(+1);
		particle->waken_up = true;
	}

	// danger affector
	bool in_danger_zone = false;
	size_t enemy_count = update_data.enemy_particles.size();
	for (size_t i = 0 ; i < enemy_count ; ++i)
		affected |= ApplyAffectorToParticles(delta_time, particle, update_data.enemy_particles[i], in_danger_zone, DANGER_RADIUS_RATIO);

	// update life and color
	if (UpdateParticleLifeAndColor(particle, in_danger_zone, delta_time, PARTICLE_LIFETIME))
	{
		if (particle->waken_up)
			game->NotifyAtomCountChange(-1);
		return true;
	}

	// final computation
	float particle_max_velocity = update_data.particle_max_velocity;

	glm::vec2 & particle_velocity = particle->velocity;

	// particle slowing down
	if (!affected)
		particle->velocity *= powf(update_data.particle_slowing_factor, delta_time);	

	// update particle velocity
	float velocity_length2 = glm::length2(particle_velocity);
	if (velocity_length2 > particle_max_velocity * particle_max_velocity)
		particle_velocity = glm::normalize(particle_velocity) * particle_max_velocity;				
	// update particle position
	particle_position += particle->velocity * (float)delta_time;

	return false;
}

ParticleAtomTrait::UpdateAtomData ParticleAtomTrait::BeginUpdateParticles(float delta_time, ParticleAtom * particles, size_t count, chaos::ParticleAllocation * allocation) const
{
	ParticleAtomTrait::UpdateAtomData result;

	ParticlePlayer const * player_particle = (ParticlePlayer const*)game->GetPlayerParticle();
	if (player_particle == nullptr)
		return result;


	result.player_particle = *player_particle;

	result.particle_slowing_factor     = game->particle_slowing_factor;	
	result.particle_max_velocity = game->particle_max_velocity;
	result.world_clamp_radius    = game->world_clamp_radius;

	game->RegisterEnemiesInRange(result.player_particle.bounding_box.position, result.world_clamp_radius, result.enemy_particles);

	return result;
}

// ===========================================================================
// Object particle system
// ===========================================================================


bool ParticleLifeTrait::UpdateParticle(float delta_time, ParticleLife * particle, chaos::ParticleAllocation * allocation) const
{

	return false;
}

size_t ParticleLifeTrait::ParticleToVertices(ParticleLife const * particle, VertexBase * vertices, size_t vertices_per_particle, chaos::ParticleAllocation * allocation) const
{
	return chaos::ParticleDefault::ParticleTrait::ParticleToVertices(particle, vertices, vertices_per_particle, allocation);
}


