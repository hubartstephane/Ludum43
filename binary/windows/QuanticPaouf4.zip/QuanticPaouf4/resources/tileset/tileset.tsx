<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tileset" tilewidth="400" tileheight="400" tilecount="4" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="5">
  <properties>
   <property name="OBJECT_TYPE" type="int" value="1"/>
  </properties>
  <image width="28" height="21" source="../sprites/flare.png"/>
 </tile>
 <tile id="6">
  <properties>
   <property name="OBJECT_TYPE" type="int" value="1"/>
  </properties>
  <image width="400" height="400" source="../sprites/planet3.png"/>
 </tile>
 <tile id="7">
  <image width="400" height="400" source="../sprites/enemy.png"/>
 </tile>
 <tile id="8">
  <image width="50" height="50" source="../sprites/Particles.png"/>
 </tile>
</tileset>
